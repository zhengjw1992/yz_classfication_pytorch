# @Time: 2019/10/8 10:38
# @Author: jwzheng
# @Function： 模型训练 和 预测 的入口
# 自定义包
import train
import data_preprocess
from config.conf import conf
from dataset import MyDataset
from model.pretrain_model import get_pretrain_model

# 系统包
import torch
from torch.utils.data import DataLoader


# 入口方法
def run():
    # 读取数据，读取成MyDataset类可以处理的格式
    train_filename_list,train_label_list = data_preprocess.read_data(train_directory=conf.train_directory,dir2label_dict=conf.dir2label_dict)
    # 定义一个数据增强的操作
    augmentation = data_preprocess.data_augmentation()
    # 使用MyDataset类和DataLoader类加载数据集
    train_dataset = MyDataset(filenames=train_filename_list, labels=train_label_list,transform=augmentation)
    train_loader = torch.utils.data.DataLoader(train_dataset,
                                               batch_size=conf.batch_size, shuffle=True,
                                               pin_memory=True)

    # 同样的方式 加载验证数据集
    test_filename_list,test_label_list = data_preprocess.read_data(train_directory=conf.val_directory,dir2label_dict=conf.dir2label_dict)
    test_dataset = MyDataset(filenames=test_filename_list, labels=test_label_list,transform=augmentation)
    test_loader = torch.utils.data.DataLoader(test_dataset,
                                                batch_size=conf.batch_size, shuffle=True,
                                                pin_memory=True)

    # 定义一个网络
    net = get_pretrain_model(conf.model_name)

    # 训练集上训练、测试集上测试效果
    train.train(net,train_loader,test_loader)


if __name__ == '__main__':
    run()