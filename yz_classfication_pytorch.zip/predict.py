# @Time: 2019/10/3 21:01
# @Author: jwzheng
# @Function：加载模型 预测
import torch
from model.pretrain_model import get_pretrain_model
import os
import dataset
from data_preprocess import data_augmentation
from torch.utils.data import TensorDataset, DataLoader, Dataset


#  加载模型
def load_model(moedl_name,model_path):
    model = get_pretrain_model(moedl_name)
    model.load_state_dict(torch.load(model_path,map_location='cpu'))
    print(model)
    return model


def read_filename_list(directory):
    image_list = os.listdir(directory)
    # data_out = open('out.csv','w',encoding='utf8')
    # count = 0
    filename_list = []
    label_list = []
    for image in image_list:
        # count +=1
        # if count %100==0:
        #     print('正在处理第{0}张图片'.format(count))
        image_path = os.path.join(directory,image)
        filename_list.append(image_path)
        # label_list.append(image.strip().split('.')[0])
        label_list.append(image)
    return filename_list,label_list


def predict(net,directory):
    filename_list,label_list = read_filename_list(directory)
    augmentation = data_augmentation()
    test_dataset = dataset.MyDataset(filename_list, label_list, augmentation)
    test_loader = torch.utils.data.DataLoader(test_dataset,
                                               batch_size=4, shuffle=False,
                                               pin_memory=True)
    data_out = open('out.csv','w',encoding='utf8')
    count = 0
    net.eval()
    with torch.no_grad():
        for input, label in test_loader:
            count+=1
            if count%100==0:
                print(count)
            out = net(input)
            print(type(input),input.shape)
            print(type(input.cuda()))
            _, pred = out.max(1)
            save_res(data_out,label,pred)
            # print('out is: \n',out)
            # print('pred is: \n',pred)
            break
    data_out.close()


def save_res(data_out,filename,pred):
    for i in range(0,len(filename)):
        data_out.write(filename[i]+','+str(pred.numpy()[i]+1)+'\n')


if __name__ == '__main__':
    directory = 'E:\收藏数据集\观云识天比赛\Test'
    model_name = 'resnext101'
    model_path = 'C:\Software\Functions\QQDocuments\\738760187\FileRecv\\model_ep7.pth'
    net = load_model(model_name,model_path)
    predict(net,directory)
